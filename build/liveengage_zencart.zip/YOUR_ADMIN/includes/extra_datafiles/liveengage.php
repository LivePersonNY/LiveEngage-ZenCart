<?php
define('BOX_CONFIGURATION_LIVEENGAGE', 'LivePerson LiveEngage');